/*
BackgroundADC.h - библиотека работы с АЦП АРДУИНО в фоновом режиме.

 Библиотека разработана Калининым Эдуардом
 http://mypractic.ru 
*/

// проверка, что библиотека еще не подключена
#ifndef BackgroundADC_h // если библиотека не подключена
#define BackgroundADC_h // тогда подключаем ее

#include "Arduino.h"

class BackgroundADC_Class {
  public:
    void analogReference(byte mode);  // ИОН
    void analogStart(byte pin); // пуск АЦП
    boolean analogCheck();  // проверка готовности данных АЦП
    unsigned int analogRead();  // чтение АЦП 
};

extern BackgroundADC_Class BackgroundADC;

#endif