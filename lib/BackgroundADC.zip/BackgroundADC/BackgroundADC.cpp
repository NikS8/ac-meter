/*
BackgroundADC.h - библиотека работы с АЦП АРДУИНО в фоновом режиме.

 Библиотека разработана Калининым Эдуардом
 http://mypractic.ru 
*/

#include "Arduino.h"
#include "BackgroundADC.h"

byte _mode = DEFAULT;

// ИОН
void BackgroundADC_Class::analogReference(byte mode) {
  _mode = mode;
}

// пуск АЦП  
void BackgroundADC_Class::analogStart(byte pin) {
  if (pin >= 14) pin -= 14;
  ADCSRB = 0;
  ADMUX = (_mode << 6) | (pin & 0x07);
  ADCSRA = 0xc7;   
}

// проверка готовности данных АЦП
boolean BackgroundADC_Class::analogCheck() {
  if ( (ADCSRA & 0x40) == 0 ) return(true);
    return(false);
}

// чтение АЦП  
unsigned int BackgroundADC_Class::analogRead() {
  return( (unsigned int)ADCL | (((unsigned int)ADCH) << 8) );    
}